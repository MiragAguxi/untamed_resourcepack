# UNTAMED Ressourcenpaket

Dieses Paket enthält das reproduzierbare Design-Grundgerüst für UNTAMED. Weitere Texturen,
Symbole und HUD-Elemente werden unter `assets/` ergänzt. Mit Gradle wird daraus eine ZIP-Datei
für einen HTTPS-Host erzeugt:

```text
gradle resourcePack
```

Die erzeugte ZIP-Datei muss extern über HTTPS erreichbar sein. Danach werden `url` und die
40-stellige SHA-1-Prüfsumme in `plugins/UNTAMED/config.yml` eingetragen. UNTAMED akzeptiert
keine HTTP-URL und sendet kein Paket ohne gültige Prüfsumme.
